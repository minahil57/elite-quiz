UPDATE `tbl_settings` SET `message` = '2.0.5' WHERE `tbl_settings`.`type` = 'system_version';
ALTER TABLE `tbl_contest` CHANGE `start_date` `start_date` DATETIME NOT NULL;
ALTER TABLE `tbl_contest` CHANGE `end_date` `end_date` DATETIME NOT NULL;
